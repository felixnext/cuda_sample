/**
 * Webservice for Stereolab. The service will listen on
 * http://HOSTNAME:PORT/Stereolab
 */
 
#include "soapH.h"
#include "StereoLabSoap12Binding.nsmap"
#include "kernel.h"

// TCP Port number
#define PORT 10000

int main(int argc, char **argv)
{
  SOAP_SOCKET m, s; /* master and slave sockets */
  struct soap soap;
  soap_init(&soap);

  m = soap_bind(&soap, NULL, PORT, 100);
    if (!soap_valid_socket(m))
    {
      soap_print_fault(&soap, stderr);
      exit(-1);
    }
    fprintf(stderr, "Socket connection successful: master socket = %d\n", m);
    for ( ; ; )
    {
      fprintf(stdout, "Waiting for client\n");
      s = soap_accept(&soap);
      fprintf(stderr, "Socket connection successful: slave socket = %d\n", s);
      if (!soap_valid_socket(s))
      {
        soap_print_fault(&soap, stderr);
        exit(-1);
      } 
      soap_serve(&soap);
      soap_end(&soap);
    }

  return 0;
} 

int __ns1__CalcImage(struct soap *soap, struct ns1__CalcImageParams *p, struct ns1__CalcImageResult *r)
{
    printf("Called CalcImage with spalten=%i, zeilen=%i, tauMax=%i, b=%i, h=%i, useS=%i, useF=%i, s=%i\n",
		p->columns, p->rows, p->tauMax, p->b,p->h,p->useS,p->useF,p->s);

    // some sanity checks to avoid surprises
    if (p->__sizeleftImage != p->rows * p->columns) {
	fprintf(stderr, "Bad size of array leftImage (%i instead of %i)\n", r->__sizeprofile, p->rows * p->columns);
	return SOAP_ERR;
    }	

    if (p->__sizerightImage != p->rows * p->columns) {
	fprintf(stderr, "Bad size of array rightImage (%i instead of %i)\n", r->__sizeprofile, p->rows * p->columns);
	return SOAP_ERR;
    }	

    // create return message (we assume gsoap will free this later :)    
    r->__sizeprofile = p->rows * p->columns;
    r->profile = (int *)calloc(p->rows * p->columns, sizeof(int));
    r->__sizevalid = p->rows * p->columns;
    r->valid = (bool *)calloc(p->rows * p->columns, sizeof(bool));
            
    // do calculation
    doCUDACalc((signed char*)p->leftImage, (signed char*)p->rightImage, p->rows, p->columns,p->tauMax, r->profile, (unsigned char*)r->valid, p->b, p->h, p->useS, p->useF, p->s);
    
    return SOAP_OK;
}

